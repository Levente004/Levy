# Egyes címsor

## 2es címsor

### 3as címsor

sima szöveg bemutatása.
sortörés
**félkövér**
ez **egy** félkövér szöveg

*döntött egy*
*döntött2*

***Ez ilyen kombinált***

~~áthúzott~~

> A kocka el van vetve. - idézet

1. első elem
2. 2nd elem
   1. ez itt a 2.1
3. 3rd elem

- bulleted list
- még egy
  - aljegyzet

```json
{
    "firstname":"John"
    "lastname":"Smith"
}
```

![magyarázó szöveg](2017-05-18_logo_de-ik_magyar.jpg)
[DEIK](https://inf.unideb.hu/ "DEIK weboldal")

Todo lista:

- [x] első
- [ ] még nem készült el

| Cím | Leírás|
|:--:| :---:|
|hosszabb szöveg | valami|
